package EmployeeManagementSystem;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;

/**
 * Whether an employee is full-time or part-time. This affects how
 * hoursWorked is expected to be used: full-time employees typically
 * work a standard number of hours per month (editable, default
 * suggested at 160 = 40hrs/week x 4 weeks), while part-time employees
 * have variable hours entered for each pay period.
 */
enum EmploymentType {
    FULL_TIME,
    PART_TIME
}

/**
 * Abstract base class for all employee types.
 * Demonstrates: encapsulation (private fields + getters/setters),
 * abstraction (abstract calculateSalary / getCategory methods), and
 * serves as the root of the inheritance hierarchy defined in Roles.java
 * (AcademicStaff, StudentServicesStaff, AdminStaff, HealthCareStaff).
 *
 * Pay is calculated on an hourly basis: hourlyRate x hoursWorked,
 * plus a category-specific bonus added by each subclass.
 */
public abstract class Employee implements Serializable {

    private static int idCounter = 1000;

    private final int id;
    private String firstName;
    private String lastName;
    private String email;
    private LocalDate dateOfBirth;
    private String jobTitle;
    private EmploymentType employmentType;
    protected double hourlyRate;
    protected double hoursWorked;

    public Employee(String firstName, String lastName, String email, LocalDate dateOfBirth,
                     String jobTitle, EmploymentType employmentType, double hourlyRate, double hoursWorked) {
        this.id = idCounter++;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.jobTitle = jobTitle;
        this.employmentType = employmentType;
        setHourlyRate(hourlyRate);
        setHoursWorked(hoursWorked);
    }

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /** Age in whole years, computed from dateOfBirth as of today. Returns -1 if unknown. */
    public int getAge() {
        if (dateOfBirth == null) return -1;
        return Period.between(dateOfBirth, LocalDate.now()).getYears();
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public EmploymentType getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(EmploymentType employmentType) {
        this.employmentType = employmentType;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        if (hourlyRate < 0) {
            throw new IllegalArgumentException("Hourly rate cannot be negative.");
        }
        this.hourlyRate = hourlyRate;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        if (hoursWorked < 0) {
            throw new IllegalArgumentException("Hours worked cannot be negative.");
        }
        this.hoursWorked = hoursWorked;
    }

    /** hourlyRate x hoursWorked, before any category-specific bonus. */
    protected double baseRegularPay() {
        return hourlyRate * hoursWorked;
    }

    /**
     * Every subclass defines how its salary is calculated on top of
     * baseRegularPay(). Calling calculateSalary() on an Employee
     * reference runs the correct subclass version at runtime -- this
     * is polymorphism.
     */
    public abstract double calculateSalary();

    /**
     * Every subclass reports which of the 4 university categories
     * it belongs to. This is derived, not stored -- so it can never
     * drift out of sync with the Department it lives in.
     */
    public abstract Category getCategory();

    @Override
    public String toString() {
        return String.format("ID: %-6d Name: %-20s Title: %-16s Type: %-10s Salary: $%,.2f",
                id, getFullName(), jobTitle, employmentType, calculateSalary());
    }

    /**
     * Converts this employee's core data into a comma-separated line
     * for saving to a text file. Subclasses append their extra fields.
     */
    public String toFileString() {
        return getClass().getSimpleName() + "," + firstName + "," + lastName + "," + email + ","
                + dateOfBirth + "," + jobTitle + "," + employmentType + "," + hourlyRate + "," + hoursWorked;
    }
}
