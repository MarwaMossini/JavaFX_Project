package EmployeeManagementSystem;

import java.util.List;

/**
 * The four top-level divisions of the university. A Department belongs
 * to exactly one Category; an Employee's category is derived from the
 * Department they work in (see Employee.getCategory()), so it is never
 * stored twice.
 */
enum Category {
    ACADEMIC,
    STUDENT_SERVICES,
    ADMINISTRATION,
    HEALTH_CARE
}

/**
 * A Department belongs to one Category and groups Employees together
 * (e.g. "Health Center" is a HEALTH_CARE department containing
 * HealthCareStaff employees). Employee storage is delegated to a
 * generic Repository<Employee> rather than a raw ArrayList directly,
 * to keep the collection logic reusable (see Repository.java).
 */
public class Department {

    private String name;
    private Category category;
    private Repository<Employee> employeeRepo;

    public Department(String name, Category category) {
        this.name = name;
        this.category = category;
        this.employeeRepo = new Repository<>();
    }

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public void addEmployee(Employee e) {
        employeeRepo.add(e);
    }

    public boolean removeEmployee(Employee e) {
        return employeeRepo.remove(e);
    }

    public Employee findEmployeeById(int id) throws EmployeeNotFoundException {
        for (Employee e : employeeRepo.getAll()) {
            if (e.getId() == id) {
                return e;
            }
        }
        throw new EmployeeNotFoundException(
                "Employee with ID " + id + " not found in department '" + name + "'.");
    }

    public List<Employee> getEmployees() {
        return employeeRepo.getAll();
    }

    public double totalSalaryExpense() {
        double total = 0;
        for (Employee e : employeeRepo.getAll()) {
            total += e.calculateSalary();
        }
        return total;
    }

    public void listEmployees() {
        System.out.println("--- Department: " + name + " (" + category + ") ---");
        if (employeeRepo.size() == 0) {
            System.out.println("(no employees yet)");
            return;
        }
        // Each call to e.calculateSalary() below is polymorphic -- AcademicStaff,
        // StudentServicesStaff, AdminStaff, and HealthCareStaff each compute it
        // differently at runtime.
        for (Employee e : employeeRepo.getAll()) {
            System.out.println(e);
        }
    }
}
