package EmployeeManagementSystem;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * JavaFX GUI entry point. All the domain logic (Employee, the 4 role
 * subclasses, Department, Category, Payroll, Repository) is unchanged
 * from the console version -- this class is purely a UI layer on top
 * of it. "Category" is kept internally (it decides pay rules and which
 * subclass gets created) but is not shown as text anywhere -- instead
 * it's represented visually as a small colored "filing tab" chip next
 * to each department, like a real registrar's color-coded folders.
 *
 * The app opens on a Home page; "Enter Employee Management System"
 * swaps the scene root to the full management screen, which has its
 * own "Home" button to go back.
 *
 * On first run (no employees.txt yet), the system seeds itself with
 * ~15 sample employees across all 4 divisions so it isn't empty.
 * Every add / update / delete is auto-saved to employees.txt
 * immediately, and the file is auto-loaded on startup after that.
 */
public class MainApp extends Application {

    private Map<String, Department> departments = new HashMap<>();
    private static final String ALL_DEPARTMENTS = "All Departments";
    private static final double DEFAULT_FULL_TIME_HOURS = 160.0;
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private Stage primaryStage;
    private Scene scene;

    private ComboBox<String> deptCombo;
    private TableView<Employee> table;
    private ObservableList<Employee> tableData = FXCollections.observableArrayList();

    private TextField firstNameField, lastNameField, emailField,
            hourlyRateField, hoursWorkedField, extraField, searchField;
    private ComboBox<String> roleCombo;
    private DatePicker dobPicker;
    private ChoiceBox<EmploymentType> employmentTypeChoice;
    private Label extraLabel;
    private Label statusLabel;
    private Label statEmployees, statPayroll;

    private static final String FILE_NAME = "employees.txt";

    // Starter role suggestions per category. Grows automatically at
    // runtime with whatever custom roles get typed in and used.
    private Map<Category, List<String>> roleSuggestions = new EnumMap<>(Category.class);

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        initializeDefaultDepartments();
        initializeRoleSuggestions();

        boolean hadExistingFile = new File(FILE_NAME).exists();
        if (hadExistingFile) {
            loadFromFileQuietly();
        } else {
            seedSampleData();
            saveToFile();
        }

        scene = new Scene(buildHomeView(), 1340, 720);
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());

        stage.setTitle("Employee Management System");
        stage.setScene(scene);
        stage.show();
    }

    private void goHome() {
        scene.setRoot(buildHomeView());
    }

    private void enterManagement() {
        Parent mgmt = buildManagementView();
        scene.setRoot(mgmt);
        refreshDeptCombo();
        refreshTable();
    }

    // ---------- Home page ----------

    private Parent buildHomeView() {
        VBox root = new VBox(18);
        root.getStyleClass().add("home-root");
        root.setAlignment(Pos.CENTER);

        ImageView logo = loadLogo();
        logo.setFitHeight(150);
        logo.setPreserveRatio(true);

        Label title = new Label("University Employee Management System");
        title.getStyleClass().add("home-title");

        Label subtitle = new Label("Registrar & Human Resources Records \u2014 Asian University for Women");
        subtitle.getStyleClass().add("home-subtitle");

        Button enterBtn = new Button("Enter Employee Management System");
        enterBtn.getStyleClass().add("btn-primary");
        enterBtn.setStyle(enterBtn.getStyle() + " -fx-font-size: 14px;");
        enterBtn.setPadding(new Insets(12, 28, 12, 28));
        enterBtn.setOnAction(e -> enterManagement());

        VBox card = new VBox(14, logo, title, subtitle, enterBtn);
        card.setAlignment(Pos.CENTER);
        card.getStyleClass().add("home-card");

        root.getChildren().add(card);
        return root;
    }

    private ImageView loadLogo() {
        try {
            Image img = new Image(getClass().getResourceAsStream("auw_logo.png"));
            return new ImageView(img);
        } catch (Exception ex) {
            return new ImageView();
        }
    }

    // ---------- Management view ----------

    private Parent buildManagementView() {
        BorderPane root = new BorderPane();

        root.setTop(buildHeader());

        HBox body = new HBox(16);
        body.setPadding(new Insets(16, 20, 16, 20));
        body.getChildren().addAll(buildLeftPanel(), buildCenterArea(), buildFormPanel());
        HBox.setHgrow(body.getChildren().get(1), Priority.ALWAYS);
        root.setCenter(body);

        root.setBottom(buildStatusBar());
        return root;
    }

    private HBox buildHeader() {
        HBox header = new HBox(14);
        header.getStyleClass().add("header-bar");
        header.setAlignment(Pos.CENTER_LEFT);

        ImageView logo = loadLogo();
        logo.setFitHeight(38);
        logo.setPreserveRatio(true);

        VBox titleBox = new VBox(2);
        Label title = new Label("University Employee Management System");
        title.getStyleClass().add("header-title");
        Label subtitle = new Label("Registrar & Human Resources Records");
        subtitle.getStyleClass().add("header-subtitle");
        titleBox.getChildren().addAll(title, subtitle);

        Button homeBtn = new Button("\u2190 Home");
        homeBtn.getStyleClass().add("btn-ghost-light");
        homeBtn.setOnAction(e -> goHome());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        statEmployees = new Label();
        statEmployees.getStyleClass().add("stat-badge");
        statPayroll = new Label();
        statPayroll.getStyleClass().add("stat-badge");

        header.getChildren().addAll(logo, titleBox, homeBtn, spacer, statEmployees, statPayroll);
        return header;
    }

    private VBox buildLeftPanel() {
        VBox box = new VBox(10);
        box.getStyleClass().add("side-panel");
        box.setPrefWidth(230);
        box.setMinWidth(230);

        Label heading = new Label("Department");
        heading.getStyleClass().add("section-heading");

        deptCombo = new ComboBox<>();
        deptCombo.getStyleClass().add("combo-box-styled");
        deptCombo.setMaxWidth(Double.MAX_VALUE);
        deptCombo.setCellFactory(lv -> deptListCell());
        deptCombo.setButtonCell(deptListCell());
        deptCombo.setOnAction(e -> {
            updateExtraLabel();
            updateRoleSuggestionsForSelectedDept();
            refreshTable();
        });

        Button addDeptBtn = new Button("Add Department...");
        addDeptBtn.getStyleClass().add("btn-secondary");
        addDeptBtn.setMaxWidth(Double.MAX_VALUE);
        addDeptBtn.setOnAction(e -> showAddDepartmentDialog());

        Button viewDeptsBtn = new Button("View Departments");
        viewDeptsBtn.getStyleClass().add("btn-secondary");
        viewDeptsBtn.setMaxWidth(Double.MAX_VALUE);
        viewDeptsBtn.setOnAction(e -> showDepartmentsDialog());

        Separator sep1 = new Separator();
        sep1.setPadding(new Insets(4, 0, 4, 0));

        Label searchHeading = new Label("Search Employee");
        searchHeading.getStyleClass().add("section-heading");
        searchField = new TextField();
        searchField.getStyleClass().add("text-field-styled");
        searchField.setPromptText("Name or ID");
        Button searchBtn = new Button("Search");
        searchBtn.getStyleClass().add("btn-secondary");
        searchBtn.setMaxWidth(Double.MAX_VALUE);
        searchBtn.setOnAction(e -> searchEmployee());

        Separator sep2 = new Separator();
        sep2.setPadding(new Insets(4, 0, 4, 0));

        Label legendHeading = new Label("Division Key");
        legendHeading.getStyleClass().add("section-heading");
        VBox legend = new VBox(6,
                legendRow("chip-academic", "Academic"),
                legendRow("chip-student", "Student Services"),
                legendRow("chip-admin", "Administration"),
                legendRow("chip-health", "Health Care"));

        box.getChildren().addAll(heading, deptCombo, addDeptBtn, viewDeptsBtn,
                sep1, searchHeading, searchField, searchBtn,
                sep2, legendHeading, legend);
        return box;
    }

    private HBox legendRow(String chipClass, String label) {
        Circle dot = new Circle(5);
        dot.getStyleClass().add(chipClass);
        Label l = new Label(label);
        l.getStyleClass().add("section-subtext");
        HBox row = new HBox(8, dot, l);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private ListCell<String> deptListCell() {
        return new ListCell<String>() {
            @Override
            protected void updateItem(String name, boolean empty) {
                super.updateItem(name, empty);
                if (empty || name == null) {
                    setGraphic(null);
                    setText(null);
                    return;
                }
                if (name.equals(ALL_DEPARTMENTS)) {
                    setText(name);
                    setStyle("-fx-text-fill: #1F2D4E;");
                    setGraphic(null);
                    return;
                }
                Department d = departments.get(name);
                Circle dot = new Circle(5);
                if (d != null) dot.getStyleClass().add(chipClassFor(d.getCategory()));
                Label lbl = new Label(name);
                lbl.setStyle("-fx-text-fill: #1F2D4E;");
                HBox row = new HBox(8, dot, lbl);
                row.setAlignment(Pos.CENTER_LEFT);
                setGraphic(row);
                setText(null);
            }
        };
    }

    private String chipClassFor(Category cat) {
        switch (cat) {
            case ACADEMIC: return "chip-academic";
            case STUDENT_SERVICES: return "chip-student";
            case ADMINISTRATION: return "chip-admin";
            case HEALTH_CARE: return "chip-health";
            default: return "chip-admin";
        }
    }

    private String hexForCategory(Category cat) {
        switch (cat) {
            case ACADEMIC: return "#1F2D4E";
            case STUDENT_SERVICES: return "#2F6F5E";
            case ADMINISTRATION: return "#5B6B7C";
            case HEALTH_CARE: return "#7A2E3B";
            default: return "#5B6B7C";
        }
    }

    private VBox buildCenterArea() {
        VBox box = new VBox(10);
        box.getChildren().add(buildTable());
        VBox.setVgrow(box.getChildren().get(0), Priority.ALWAYS);
        return box;
    }

    private TableView<Employee> buildTable() {
        table = new TableView<>();
        table.getStyleClass().add("table-view-styled");
        table.setItems(tableData);
        Label placeholder = new Label("No employees to show yet. Add one from the right-hand panel.");
        placeholder.getStyleClass().add("placeholder-text");
        table.setPlaceholder(placeholder);
        VBox.setVgrow(table, Priority.ALWAYS);

        TableColumn<Employee, Number> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getId()));
        idCol.setPrefWidth(62);

        TableColumn<Employee, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getFullName()));
        nameCol.setPrefWidth(128);

        TableColumn<Employee, String> titleCol = new TableColumn<>("Role");
        titleCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getJobTitle()));
        titleCol.setPrefWidth(150);

        TableColumn<Employee, Employee> deptCol = new TableColumn<>("Department");
        deptCol.setCellValueFactory(c -> new javafx.beans.property.SimpleObjectProperty<>(c.getValue()));
        deptCol.setPrefWidth(155);
        deptCol.setCellFactory(col -> new TableCell<Employee, Employee>() {
            @Override
            protected void updateItem(Employee emp, boolean empty) {
                super.updateItem(emp, empty);
                if (empty || emp == null) { setGraphic(null); return; }
                Department d = findDepartmentOf(emp);
                Circle dot = new Circle(5);
                if (d != null) dot.getStyleClass().add(chipClassFor(d.getCategory()));
                Label lbl = new Label(d == null ? "" : d.getName());
                HBox row = new HBox(8, dot, lbl);
                row.setAlignment(Pos.CENTER_LEFT);
                setGraphic(row);
            }
        });

        TableColumn<Employee, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getEmploymentType() == EmploymentType.FULL_TIME ? "Full-time" : "Part-time"));
        typeCol.setPrefWidth(95);

        TableColumn<Employee, Number> ageCol = new TableColumn<>("Age");
        ageCol.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getAge()));
        ageCol.setPrefWidth(50);

        TableColumn<Employee, String> salaryCol = new TableColumn<>("Salary");
        salaryCol.setCellValueFactory(c -> new SimpleStringProperty(String.format("$%,.2f", c.getValue().calculateSalary())));
        salaryCol.setPrefWidth(105);
        salaryCol.setCellFactory(col -> new TableCell<Employee, String>() {
            @Override
            protected void updateItem(String value, boolean empty) {
                super.updateItem(value, empty);
                setText(empty ? null : value);
                getStyleClass().removeAll("salary-cell");
                if (!empty) getStyleClass().add("salary-cell");
            }
        });

        table.getColumns().addAll(idCol, nameCol, titleCol, deptCol, typeCol, ageCol, salaryCol);
        return table;
    }

    private VBox buildFormPanel() {
        VBox box = new VBox(7);
        box.getStyleClass().add("side-panel");
        box.setPrefWidth(255);
        box.setMinWidth(255);

        Label heading = new Label("Add Employee");
        heading.getStyleClass().add("section-heading");

        firstNameField = styledField("First name");
        lastNameField = styledField("Last name");
        emailField = styledField("Email");

        Label dobLabel = new Label("Date of birth");
        dobLabel.getStyleClass().add("section-subtext");
        dobPicker = new DatePicker();
        dobPicker.setConverter(isoDateConverter());
        dobPicker.getStyleClass().add("combo-box-styled");
        dobPicker.setMaxWidth(Double.MAX_VALUE);
        dobPicker.setPromptText("YYYY-MM-DD");

        Label roleLabel = new Label("Role");
        roleLabel.getStyleClass().add("section-subtext");
        roleCombo = new ComboBox<>();
        roleCombo.setEditable(true);
        roleCombo.getStyleClass().add("combo-box-styled");
        roleCombo.setMaxWidth(Double.MAX_VALUE);
        roleCombo.setPromptText("Pick or type a role");

        Label typeLabel = new Label("Employment type");
        typeLabel.getStyleClass().add("section-subtext");
        employmentTypeChoice = new ChoiceBox<>(FXCollections.observableArrayList(EmploymentType.values()));
        employmentTypeChoice.setConverter(employmentTypeConverter());
        employmentTypeChoice.setValue(EmploymentType.FULL_TIME);
        employmentTypeChoice.setMaxWidth(Double.MAX_VALUE);
        employmentTypeChoice.getStyleClass().add("combo-box-styled");
        employmentTypeChoice.setOnAction(e -> {
            if (employmentTypeChoice.getValue() == EmploymentType.FULL_TIME) {
                hoursWorkedField.setText(String.valueOf((int) DEFAULT_FULL_TIME_HOURS));
            } else {
                hoursWorkedField.clear();
            }
        });

        hourlyRateField = styledField("Hourly rate ($)");
        hoursWorkedField = styledField("Hours worked");
        hoursWorkedField.setText(String.valueOf((int) DEFAULT_FULL_TIME_HOURS));

        extraLabel = new Label("Extra field");
        extraLabel.getStyleClass().add("section-subtext");
        extraField = styledField(null);

        Button addBtn = new Button("Add Employee");
        addBtn.getStyleClass().add("btn-primary");
        addBtn.setMaxWidth(Double.MAX_VALUE);
        addBtn.setOnAction(e -> addEmployee());

        Separator sep = new Separator();
        sep.setPadding(new Insets(4, 0, 4, 0));

        box.getChildren().addAll(heading, firstNameField, lastNameField, emailField,
                dobLabel, dobPicker, roleLabel, roleCombo,
                typeLabel, employmentTypeChoice, hourlyRateField, hoursWorkedField,
                extraLabel, extraField, addBtn, sep, buildActionButtons());

        ScrollPane scroll = new ScrollPane(box);
        scroll.setFitToWidth(true);
        scroll.getStyleClass().add("edge-to-edge");
        VBox wrapper = new VBox(scroll);
        wrapper.setPrefWidth(255);
        wrapper.setMinWidth(255);
        VBox.setVgrow(scroll, Priority.ALWAYS);
        return wrapper;
    }

    private TextField styledField(String prompt) {
        TextField f = new TextField();
        f.getStyleClass().add("text-field-styled");
        if (prompt != null) f.setPromptText(prompt);
        return f;
    }

    private VBox buildActionButtons() {
        VBox box = new VBox(8);

        Button updateBtn = new Button("Update Employee...");
        updateBtn.getStyleClass().add("btn-secondary");
        updateBtn.setMaxWidth(Double.MAX_VALUE);
        updateBtn.setOnAction(e -> updateSelectedEmployee());

        Button deleteBtn = new Button("Delete Employee");
        deleteBtn.getStyleClass().add("btn-danger");
        deleteBtn.setMaxWidth(Double.MAX_VALUE);
        deleteBtn.setOnAction(e -> deleteSelectedEmployee());

        Button payslipBtn = new Button("Generate Payslip (Selected)");
        payslipBtn.getStyleClass().add("btn-secondary");
        payslipBtn.setMaxWidth(Double.MAX_VALUE);
        payslipBtn.setOnAction(e -> generatePayslipForSelected());

        box.getChildren().addAll(updateBtn, deleteBtn, payslipBtn);
        return box;
    }

    private HBox buildStatusBar() {
        HBox bar = new HBox(8);
        bar.getStyleClass().add("status-bar");
        bar.setPadding(new Insets(10, 20, 10, 20));
        bar.setAlignment(Pos.CENTER_LEFT);

        Button viewAllBtn = new Button("View Employees");
        viewAllBtn.getStyleClass().add("btn-secondary");
        viewAllBtn.setOnAction(e -> {
            deptCombo.setValue(ALL_DEPARTMENTS);
            updateExtraLabel();
            refreshTable();
        });

        Button payrollBtn = new Button("Payroll");
        payrollBtn.getStyleClass().add("btn-secondary");
        payrollBtn.setOnAction(e -> showPayrollDialog());

        Button statsBtn = new Button("Statistics");
        statsBtn.getStyleClass().add("btn-secondary");
        statsBtn.setOnAction(e -> showStatisticsDialog());

        Button printBtn = new Button("Print");
        printBtn.getStyleClass().add("btn-secondary");
        printBtn.setOnAction(e -> printEmployeeList());

        Button saveBtn = new Button("Save Records");
        saveBtn.getStyleClass().add("btn-secondary");
        saveBtn.setOnAction(e -> {
            saveToFile();
            setStatus("Records saved.");
        });

        Button loadBtn = new Button("Load Records");
        loadBtn.getStyleClass().add("btn-secondary");
        loadBtn.setOnAction(e -> loadFromFileButton());

        Button exitBtn = new Button("Exit");
        exitBtn.getStyleClass().add("btn-ghost");
        exitBtn.setOnAction(e -> Platform.exit());

        statusLabel = new Label("Ready.");
        statusLabel.getStyleClass().add("status-label");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        bar.getChildren().addAll(viewAllBtn, payrollBtn, statsBtn, printBtn, saveBtn, loadBtn, exitBtn, spacer, statusLabel);
        return bar;
    }

    // ---------- default data ----------

    private void initializeDefaultDepartments() {
        addDefaultDept("Undergraduate", Category.ACADEMIC);
        addDefaultDept("Graduate", Category.ACADEMIC);
        addDefaultDept("Pathway", Category.ACADEMIC);
        addDefaultDept("School", Category.ACADEMIC);
        addDefaultDept("Fellows", Category.ACADEMIC);

        addDefaultDept("Registration", Category.STUDENT_SERVICES);
        addDefaultDept("Residential Life", Category.STUDENT_SERVICES);
        addDefaultDept("Library", Category.STUDENT_SERVICES);
        addDefaultDept("Visa Office", Category.STUDENT_SERVICES);
        addDefaultDept("Work-Study", Category.STUDENT_SERVICES);

        addDefaultDept("Finance", Category.ADMINISTRATION);
        addDefaultDept("IT", Category.ADMINISTRATION);
        addDefaultDept("Housekeeping", Category.ADMINISTRATION);
        addDefaultDept("Maintenance", Category.ADMINISTRATION);
        addDefaultDept("Security", Category.ADMINISTRATION);

        addDefaultDept("Health Center", Category.HEALTH_CARE);
        addDefaultDept("Mental Health", Category.HEALTH_CARE);
    }

    private void addDefaultDept(String name, Category category) {
        departments.put(name, new Department(name, category));
    }

    private void initializeRoleSuggestions() {
        roleSuggestions.put(Category.ACADEMIC, new ArrayList<>(Arrays.asList(
                "Professor", "Associate Professor", "Assistant Professor", "Lecturer",
                "Teaching Assistant", "Dean", "Program Coordinator", "Research Fellow")));
        roleSuggestions.put(Category.STUDENT_SERVICES, new ArrayList<>(Arrays.asList(
                "Registrar", "Admissions Officer", "Librarian", "Residential Life Coordinator",
                "Visa Officer", "Work-Study Supervisor")));
        roleSuggestions.put(Category.ADMINISTRATION, new ArrayList<>(Arrays.asList(
                "Accountant", "Finance Officer", "IT Support Specialist", "Systems Administrator",
                "Housekeeping Supervisor", "Maintenance Technician", "Security Guard")));
        roleSuggestions.put(Category.HEALTH_CARE, new ArrayList<>(Arrays.asList(
                "Doctor", "Nurse", "Psychologist", "Counselor", "Pharmacist", "Lab Technician")));
    }

    private void updateRoleSuggestionsForSelectedDept() {
        Department dept = getSelectedDepartment();
        if (dept == null) {
            roleCombo.setItems(FXCollections.observableArrayList());
            return;
        }
        Category cat = dept.getCategory();
        // Merge the starter list with any roles already in use for this category.
        LinkedHashSet<String> merged = new LinkedHashSet<>(roleSuggestions.get(cat));
        for (Department d : departments.values()) {
            if (d.getCategory() == cat) {
                for (Employee e : d.getEmployees()) merged.add(e.getJobTitle());
            }
        }
        List<String> sorted = new ArrayList<>(merged);
        Collections.sort(sorted);
        roleCombo.setItems(FXCollections.observableArrayList(sorted));
    }

    private void rememberRole(Category cat, String role) {
        if (role == null || role.trim().isEmpty()) return;
        List<String> list = roleSuggestions.get(cat);
        if (!list.contains(role)) list.add(role);
    }

    private Category categoryFromType(String type) {
        switch (type) {
            case "AcademicStaff": return Category.ACADEMIC;
            case "StudentServicesStaff": return Category.STUDENT_SERVICES;
            case "AdminStaff": return Category.ADMINISTRATION;
            case "HealthCareStaff": return Category.HEALTH_CARE;
            default: return Category.ADMINISTRATION;
        }
    }

    /**
     * DatePicker doesn't always commit typed text to its value on Tab/focus-loss
     * in every JavaFX version, so this reads the editor's raw text directly as
     * a fallback -- guaranteeing a typed date is never silently lost.
     */
    private LocalDate resolveDatePickerValue(DatePicker picker) {
        if (picker.getValue() != null) return picker.getValue();
        String text = picker.getEditor().getText();
        if (text == null || text.trim().isEmpty()) return null;
        try {
            return LocalDate.parse(text.trim(), DATE_FMT);
        } catch (Exception ex) {
            return null;
        }
    }

    private StringConverter<LocalDate> isoDateConverter() {
        return new StringConverter<LocalDate>() {
            @Override
            public String toString(LocalDate date) {
                return date == null ? "" : DATE_FMT.format(date);
            }
            @Override
            public LocalDate fromString(String s) {
                if (s == null || s.trim().isEmpty()) return null;
                try {
                    return LocalDate.parse(s.trim(), DATE_FMT);
                } catch (Exception ex) {
                    return null;
                }
            }
        };
    }

    private javafx.util.StringConverter<EmploymentType> employmentTypeConverter() {
        return new javafx.util.StringConverter<EmploymentType>() {
            @Override
            public String toString(EmploymentType t) {
                if (t == null) return "";
                return t == EmploymentType.FULL_TIME ? "Full-time" : "Part-time";
            }
            @Override
            public EmploymentType fromString(String s) {
                return "Full-time".equals(s) ? EmploymentType.FULL_TIME : EmploymentType.PART_TIME;
            }
        };
    }

    // ---------- sample seed data (first run only) ----------

    private void seedSampleData() {
        addSeed("Undergraduate", "AcademicStaff", "Nusrat", "Jahan", "nusrat.jahan@auw.edu.bd", "1988-04-12", "Lecturer", EmploymentType.FULL_TIME, 28, 160, 10);
        addSeed("Graduate", "AcademicStaff", "Farhana", "Akter", "farhana.akter@auw.edu.bd", "1979-11-02", "Associate Professor", EmploymentType.FULL_TIME, 35, 160, 15);
        addSeed("Fellows", "AcademicStaff", "Ayesha", "Siddiqua", "ayesha.siddiqua@auw.edu.bd", "1993-07-19", "Research Fellow", EmploymentType.PART_TIME, 22, 80, 5);

        addSeed("Registration", "StudentServicesStaff", "Tania", "Rahman", "tania.rahman@auw.edu.bd", "1985-02-27", "Registrar", EmploymentType.FULL_TIME, 20, 160, 200);
        addSeed("Library", "StudentServicesStaff", "Sabrina", "Islam", "sabrina.islam@auw.edu.bd", "1990-09-08", "Librarian", EmploymentType.FULL_TIME, 18, 160, 150);
        addSeed("Residential Life", "StudentServicesStaff", "Mou", "Chowdhury", "mou.chowdhury@auw.edu.bd", "1992-05-15", "Residential Life Coordinator", EmploymentType.FULL_TIME, 19, 160, 180);
        addSeed("Visa Office", "StudentServicesStaff", "Rima", "Akhtar", "rima.akhtar@auw.edu.bd", "1996-01-30", "Visa Officer", EmploymentType.PART_TIME, 17, 90, 100);

        addSeed("Finance", "AdminStaff", "Kamal", "Hossain", "kamal.hossain@auw.edu.bd", "1982-06-21", "Accountant", EmploymentType.FULL_TIME, 24, 160, 5);
        addSeed("IT", "AdminStaff", "Shahriar", "Kabir", "shahriar.kabir@auw.edu.bd", "1991-03-03", "IT Support Specialist", EmploymentType.FULL_TIME, 23, 160, 3);
        addSeed("Housekeeping", "AdminStaff", "Rehana", "Begum", "rehana.begum@auw.edu.bd", "1975-12-11", "Housekeeping Supervisor", EmploymentType.FULL_TIME, 12, 160, 8);
        addSeed("Security", "AdminStaff", "Abdul", "Karim", "abdul.karim@auw.edu.bd", "1980-08-25", "Security Guard", EmploymentType.FULL_TIME, 11, 160, 10);
        addSeed("Maintenance", "AdminStaff", "Jashim", "Uddin", "jashim.uddin@auw.edu.bd", "1987-10-05", "Maintenance Technician", EmploymentType.PART_TIME, 13, 100, 4);

        addSeed("Health Center", "HealthCareStaff", "Nasima", "Khatun", "dr.nasima.khatun@auw.edu.bd", "1978-01-17", "Doctor", EmploymentType.FULL_TIME, 40, 160, 500);
        addSeed("Mental Health", "HealthCareStaff", "Farzana", "Yasmin", "dr.farzana.yasmin@auw.edu.bd", "1984-04-29", "Psychologist", EmploymentType.FULL_TIME, 32, 160, 300);
        addSeed("Health Center", "HealthCareStaff", "Sultana", "Parveen", "sultana.parveen@auw.edu.bd", "1994-09-14", "Nurse", EmploymentType.FULL_TIME, 18, 160, 150);
    }

    private void addSeed(String deptName, String type, String first, String last, String email,
                          String dobStr, String role, EmploymentType empType, double rate, double hours, double extra) {
        Department dept = departments.get(deptName);
        if (dept == null) return;
        LocalDate dob = LocalDate.parse(dobStr);
        Employee emp;
        switch (type) {
            case "AcademicStaff":
                emp = new AcademicStaff(first, last, email, dob, role, empType, rate, hours, extra); break;
            case "StudentServicesStaff":
                emp = new StudentServicesStaff(first, last, email, dob, role, empType, rate, hours, extra); break;
            case "AdminStaff":
                emp = new AdminStaff(first, last, email, dob, role, empType, rate, hours, extra); break;
            case "HealthCareStaff":
                emp = new HealthCareStaff(first, last, email, dob, role, empType, rate, hours, extra); break;
            default:
                return;
        }
        dept.addEmployee(emp);
        rememberRole(dept.getCategory(), role);
    }

    // ---------- data / UI sync ----------

    private void refreshDeptCombo() {
        List<String> names = new ArrayList<>(departments.keySet());
        Collections.sort(names);
        names.add(0, ALL_DEPARTMENTS);
        String previous = deptCombo.getValue();
        deptCombo.setItems(FXCollections.observableArrayList(names));
        if (previous != null && names.contains(previous)) {
            deptCombo.setValue(previous);
        } else {
            deptCombo.setValue(ALL_DEPARTMENTS);
        }
        updateExtraLabel();
        updateRoleSuggestionsForSelectedDept();
    }

    private Department getSelectedDepartment() {
        String name = deptCombo.getValue();
        if (name == null || name.equals(ALL_DEPARTMENTS)) return null;
        return departments.get(name);
    }

    private Department findDepartmentOf(Employee emp) {
        for (Department d : departments.values()) {
            if (d.getEmployees().contains(emp)) return d;
        }
        return null;
    }

    private void updateExtraLabel() {
        Department dept = getSelectedDepartment();
        if (dept == null) {
            extraLabel.setText("Select a department to add an employee");
            return;
        }
        switch (dept.getCategory()) {
            case ACADEMIC: extraLabel.setText("Research allowance %"); break;
            case STUDENT_SERVICES: extraLabel.setText("Shift allowance ($)"); break;
            case ADMINISTRATION: extraLabel.setText("Overtime hours (paid 1.5x)"); break;
            case HEALTH_CARE: extraLabel.setText("On-call bonus ($)"); break;
        }
    }

    private void refreshTable() {
        Department dept = getSelectedDepartment();
        tableData.clear();
        if (dept != null) {
            tableData.addAll(dept.getEmployees());
        } else {
            for (Department d : departments.values()) {
                tableData.addAll(d.getEmployees());
            }
        }
        updateHeaderStats();
    }

    private void updateHeaderStats() {
        int total = 0;
        double payroll = 0;
        for (Department d : departments.values()) {
            total += d.getEmployees().size();
            payroll += d.totalSalaryExpense();
        }
        statEmployees.setText(total + (total == 1 ? " employee" : " employees"));
        statPayroll.setText(String.format("$%,.0f payroll", payroll));
    }

    // ---------- actions ----------

    private void showAddDepartmentDialog() {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Add Department");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        TextField nameF = new TextField();
        nameF.setPromptText("Department name");
        ChoiceBox<Category> catBox = new ChoiceBox<>(FXCollections.observableArrayList(Category.values()));
        catBox.setValue(Category.ACADEMIC);

        VBox content = new VBox(8, new Label("Name:"), nameF, new Label("Pay structure:"), catBox);
        content.setPadding(new Insets(10));
        dialog.getDialogPane().setContent(content);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                String name = nameF.getText().trim();
                if (name.isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, "Department name cannot be empty.");
                } else if (departments.containsKey(name)) {
                    showAlert(Alert.AlertType.ERROR, "A department with that name already exists.");
                } else {
                    departments.put(name, new Department(name, catBox.getValue()));
                    refreshDeptCombo();
                    deptCombo.setValue(name);
                    refreshTable();
                    setStatus("Department '" + name + "' added.");
                }
            }
            return null;
        });
        dialog.showAndWait();
    }

    private void showDepartmentsDialog() {
        TableView<Department> deptTable = new TableView<>();
        deptTable.getStyleClass().add("table-view-styled");
        List<Department> deptList = new ArrayList<>(departments.values());
        deptList.sort(Comparator.comparing(Department::getName));
        deptTable.setItems(FXCollections.observableArrayList(deptList));

        TableColumn<Department, Department> nameCol = new TableColumn<>("Department");
        nameCol.setCellValueFactory(c -> new javafx.beans.property.SimpleObjectProperty<>(c.getValue()));
        nameCol.setPrefWidth(200);
        nameCol.setCellFactory(col -> new TableCell<Department, Department>() {
            @Override
            protected void updateItem(Department d, boolean empty) {
                super.updateItem(d, empty);
                if (empty || d == null) { setGraphic(null); return; }
                Circle dot = new Circle(5);
                dot.getStyleClass().add(chipClassFor(d.getCategory()));
                HBox row = new HBox(8, dot, new Label(d.getName()));
                row.setAlignment(Pos.CENTER_LEFT);
                setGraphic(row);
            }
        });

        TableColumn<Department, Number> countCol = new TableColumn<>("Employees");
        countCol.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getEmployees().size()));
        countCol.setPrefWidth(100);

        TableColumn<Department, String> totalCol = new TableColumn<>("Total Payroll");
        totalCol.setCellValueFactory(c -> new SimpleStringProperty(String.format("$%,.2f", c.getValue().totalSalaryExpense())));
        totalCol.setPrefWidth(150);

        deptTable.getColumns().addAll(nameCol, countCol, totalCol);
        deptTable.setPrefSize(480, 420);

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("All Departments");
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.getDialogPane().setContent(deptTable);
        dialog.showAndWait();
    }

    private void addEmployee() {
        Department dept = getSelectedDepartment();
        if (dept == null) {
            showAlert(Alert.AlertType.ERROR, "Select a specific department first (not \"All Departments\").");
            return;
        }
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        String jobTitle = roleCombo.getEditor().getText().trim();
        LocalDate dob = resolveDatePickerValue(dobPicker);
        if (firstName.isEmpty() || lastName.isEmpty() || jobTitle.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "First name, last name, and role are required.");
            return;
        }
        if (dob == null) {
            showAlert(Alert.AlertType.ERROR, "Enter a valid date of birth as YYYY-MM-DD, or pick one from the calendar.");
            return;
        }
        EmploymentType type = employmentTypeChoice.getValue();

        try {
            double hourlyRate = Double.parseDouble(hourlyRateField.getText().trim());
            double hoursWorked = Double.parseDouble(hoursWorkedField.getText().trim());
            Employee emp;
            switch (dept.getCategory()) {
                case ACADEMIC:
                    emp = new AcademicStaff(firstName, lastName, email, dob, jobTitle, type, hourlyRate, hoursWorked,
                            Double.parseDouble(extraField.getText().trim()));
                    break;
                case STUDENT_SERVICES:
                    emp = new StudentServicesStaff(firstName, lastName, email, dob, jobTitle, type, hourlyRate, hoursWorked,
                            Double.parseDouble(extraField.getText().trim()));
                    break;
                case ADMINISTRATION:
                    emp = new AdminStaff(firstName, lastName, email, dob, jobTitle, type, hourlyRate, hoursWorked,
                            Double.parseDouble(extraField.getText().trim()));
                    break;
                case HEALTH_CARE:
                    emp = new HealthCareStaff(firstName, lastName, email, dob, jobTitle, type, hourlyRate, hoursWorked,
                            Double.parseDouble(extraField.getText().trim()));
                    break;
                default:
                    return;
            }
            dept.addEmployee(emp);
            rememberRole(dept.getCategory(), jobTitle);
            updateRoleSuggestionsForSelectedDept();
            refreshTable();
            clearForm();
            saveToFile();
            setStatus("Added employee ID " + emp.getId() + " to " + dept.getName() + ". Saved.");
        } catch (NumberFormatException ex) {
            showAlert(Alert.AlertType.ERROR, "Hourly rate, hours worked, and the extra field must be valid numbers.");
        } catch (IllegalArgumentException ex) {
            showAlert(Alert.AlertType.ERROR, ex.getMessage());
        }
    }

    private void clearForm() {
        firstNameField.clear();
        lastNameField.clear();
        emailField.clear();
        dobPicker.setValue(null);
        roleCombo.getEditor().clear();
        roleCombo.setValue(null);
        hourlyRateField.clear();
        employmentTypeChoice.setValue(EmploymentType.FULL_TIME);
        hoursWorkedField.setText(String.valueOf((int) DEFAULT_FULL_TIME_HOURS));
        extraField.clear();
    }

    private void searchEmployee() {
        String query = searchField.getText().trim();
        if (query.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Type a name or ID to search for.");
            return;
        }
        Employee found = null;
        for (Department d : departments.values()) {
            for (Employee e : d.getEmployees()) {
                boolean idMatch = String.valueOf(e.getId()).equals(query);
                boolean nameMatch = e.getFullName().toLowerCase().contains(query.toLowerCase());
                if (idMatch || nameMatch) { found = e; break; }
            }
            if (found != null) break;
        }
        if (found == null) {
            showAlert(Alert.AlertType.INFORMATION, "No employee found matching \"" + query + "\".");
            return;
        }
        deptCombo.setValue(ALL_DEPARTMENTS);
        updateExtraLabel();
        refreshTable();
        table.getSelectionModel().select(found);
        table.scrollTo(found);
        setStatus("Found: " + found.getFullName() + " (ID " + found.getId() + ").");
    }

    private void updateSelectedEmployee() {
        Employee selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.ERROR, "Select an employee in the table first.");
            return;
        }
        Department dept = findDepartmentOf(selected);

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Update Employee");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        TextField firstF = new TextField(selected.getFirstName());
        TextField lastF = new TextField(selected.getLastName());
        TextField emailF = new TextField(selected.getEmail());
        DatePicker dobF = new DatePicker(selected.getDateOfBirth());
        dobF.setConverter(isoDateConverter());

        ComboBox<String> roleF = new ComboBox<>();
        roleF.setEditable(true);
        if (dept != null) {
            LinkedHashSet<String> merged = new LinkedHashSet<>(roleSuggestions.get(dept.getCategory()));
            roleF.setItems(FXCollections.observableArrayList(merged));
        }
        roleF.setValue(selected.getJobTitle());
        roleF.getEditor().setText(selected.getJobTitle());

        ChoiceBox<EmploymentType> typeF = new ChoiceBox<>(FXCollections.observableArrayList(EmploymentType.values()));
        typeF.setConverter(employmentTypeConverter());
        typeF.setValue(selected.getEmploymentType());
        TextField rateF = new TextField(String.valueOf(selected.getHourlyRate()));
        TextField hoursF = new TextField(String.valueOf(selected.getHoursWorked()));

        VBox content = new VBox(8,
                new Label("First name:"), firstF,
                new Label("Last name:"), lastF,
                new Label("Email:"), emailF,
                new Label("Date of birth:"), dobF,
                new Label("Role:"), roleF,
                new Label("Employment type:"), typeF,
                new Label("Hourly rate ($):"), rateF,
                new Label("Hours worked:"), hoursF);
        content.setPadding(new Insets(10));
        ScrollPane scrollContent = new ScrollPane(content);
        scrollContent.setFitToWidth(true);
        scrollContent.setPrefHeight(460);
        dialog.getDialogPane().setContent(scrollContent);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                try {
                    selected.setFirstName(firstF.getText().trim());
                    selected.setLastName(lastF.getText().trim());
                    selected.setEmail(emailF.getText().trim());
                    selected.setDateOfBirth(resolveDatePickerValue(dobF));
                    selected.setJobTitle(roleF.getEditor().getText().trim());
                    selected.setEmploymentType(typeF.getValue());
                    selected.setHourlyRate(Double.parseDouble(rateF.getText().trim()));
                    selected.setHoursWorked(Double.parseDouble(hoursF.getText().trim()));
                    if (dept != null) rememberRole(dept.getCategory(), selected.getJobTitle());
                    refreshTable();
                    saveToFile();
                    setStatus("Updated " + selected.getFullName() + ". Saved.");
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Hourly rate and hours worked must be valid numbers.");
                } catch (IllegalArgumentException ex) {
                    showAlert(Alert.AlertType.ERROR, ex.getMessage());
                }
            }
            return null;
        });
        dialog.showAndWait();
    }

    private void deleteSelectedEmployee() {
        Employee selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.ERROR, "Select an employee in the table first.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete " + selected.getFullName() + " (ID " + selected.getId() + ")?", ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Delete");
        confirm.setHeaderText(null);
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                Department dept = findDepartmentOf(selected);
                if (dept != null) {
                    dept.removeEmployee(selected);
                    refreshTable();
                    saveToFile();
                    setStatus("Deleted " + selected.getFullName() + ". Saved.");
                }
            }
        });
    }

    private void generatePayslipForSelected() {
        Employee selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.ERROR, "Select an employee in the table first.");
            return;
        }
        Department dept = findDepartmentOf(selected);
        String dobStr = selected.getDateOfBirth() == null ? "Unknown" :
                selected.getDateOfBirth().format(DATE_FMT) + " (age " + selected.getAge() + ")";
        String payslip = String.format(
                "Employee    : %s (ID: %d)%nEmail       : %s%nDate of Birth: %s%nRole        : %s%nDepartment  : %s%nType        : %s%nHourly Rate : $%,.2f%nHours       : %.1f%n%nNet Pay     : $%,.2f",
                selected.getFullName(), selected.getId(), selected.getEmail(), dobStr, selected.getJobTitle(),
                dept == null ? "" : dept.getName(),
                selected.getEmploymentType() == EmploymentType.FULL_TIME ? "Full-time" : "Part-time",
                selected.getHourlyRate(), selected.getHoursWorked(), selected.calculateSalary());
        showAlert(Alert.AlertType.INFORMATION, payslip, "Payslip");
    }

    private void showPayrollDialog() {
        Department dept = getSelectedDepartment();
        StringBuilder sb = new StringBuilder();
        if (dept != null) {
            sb.append(String.format("%s payroll: $%,.2f%n%n", dept.getName(), dept.totalSalaryExpense()));
        }
        sb.append(String.format("Total university payroll: $%,.2f", Payroll.calculateCompanyPayroll(departments)));
        showAlert(Alert.AlertType.INFORMATION, sb.toString(), "Payroll");
    }

    private void showStatisticsDialog() {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Division");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Employees");

        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
        chart.setLegendVisible(false);
        chart.setPrefSize(520, 380);
        chart.setTitle("Employees by Division");

        Map<Category, Integer> counts = new EnumMap<>(Category.class);
        for (Category c : Category.values()) counts.put(c, 0);
        for (Department d : departments.values()) {
            counts.put(d.getCategory(), counts.get(d.getCategory()) + d.getEmployees().size());
        }

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (Category c : Category.values()) {
            String label;
            switch (c) {
                case ACADEMIC: label = "Academic"; break;
                case STUDENT_SERVICES: label = "Student\nServices"; break;
                case ADMINISTRATION: label = "Admin"; break;
                default: label = "Health\nCare"; break;
            }
            series.getData().add(new XYChart.Data<>(label, counts.get(c)));
        }
        chart.getData().add(series);

        VBox content = new VBox(10, chart);
        content.setPadding(new Insets(10));

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Statistics");
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.getDialogPane().setContent(content);
        dialog.show();

        Category[] cats = Category.values();
        for (int i = 0; i < series.getData().size(); i++) {
            XYChart.Data<String, Number> d = series.getData().get(i);
            Node node = d.getNode();
            if (node != null) {
                node.setStyle("-fx-bar-fill: " + hexForCategory(cats[i]) + ";");
            } else {
                final int idx = i;
                d.nodeProperty().addListener((obs, oldN, newN) -> {
                    if (newN != null) newN.setStyle("-fx-bar-fill: " + hexForCategory(cats[idx]) + ";");
                });
            }
        }
    }

    private void printEmployeeList() {
        PrinterJob job = PrinterJob.createPrinterJob();
        if (job == null) {
            showAlert(Alert.AlertType.ERROR, "No printer service is available on this computer.");
            return;
        }
        boolean proceed = job.showPrintDialog(primaryStage);
        if (!proceed) return;

        Node report = buildPrintableReport();
        boolean success = job.printPage(report);
        if (success) {
            job.endJob();
            setStatus("Employee list sent to printer.");
        } else {
            showAlert(Alert.AlertType.ERROR, "Printing failed.");
        }
    }

    private Node buildPrintableReport() {
        VBox page = new VBox(6);
        page.setPadding(new Insets(20));
        page.setStyle("-fx-background-color: white;");

        Text title = new Text("University Employee Management System \u2014 Employee Report");
        title.setFont(Font.font("Cambria", FontWeight.BOLD, 16));

        Text dateText = new Text("Generated: " + LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy")));
        dateText.setFont(Font.font("Segoe UI", 10));

        GridPane grid = new GridPane();
        grid.setHgap(14);
        grid.setVgap(4);
        grid.setPadding(new Insets(14, 0, 0, 0));

        String[] headers = {"ID", "Name", "Role", "Department", "Type", "Age", "Salary"};
        for (int i = 0; i < headers.length; i++) {
            Text h = new Text(headers[i]);
            h.setFont(Font.font("Segoe UI", FontWeight.BOLD, 11));
            grid.add(h, i, 0);
        }

        List<Department> sortedDepts = new ArrayList<>(departments.values());
        sortedDepts.sort(Comparator.comparing(Department::getName));

        int row = 1;
        for (Department d : sortedDepts) {
            List<Employee> emps = new ArrayList<>(d.getEmployees());
            emps.sort(Comparator.comparing(Employee::getFullName));
            for (Employee e : emps) {
                grid.add(new Text(String.valueOf(e.getId())), 0, row);
                grid.add(new Text(e.getFullName()), 1, row);
                grid.add(new Text(e.getJobTitle()), 2, row);
                grid.add(new Text(d.getName()), 3, row);
                grid.add(new Text(e.getEmploymentType() == EmploymentType.FULL_TIME ? "FT" : "PT"), 4, row);
                grid.add(new Text(String.valueOf(e.getAge())), 5, row);
                grid.add(new Text(String.format("$%,.2f", e.calculateSalary())), 6, row);
                row++;
            }
        }
        for (Node n : grid.getChildren()) {
            if (n instanceof Text && GridPane.getRowIndex(n) != null && GridPane.getRowIndex(n) != 0) {
                ((Text) n).setFont(Font.font("Segoe UI", 10.5));
            }
        }

        Text totalText = new Text(String.format("%nTotal university payroll: $%,.2f", Payroll.calculateCompanyPayroll(departments)));
        totalText.setFont(Font.font("Segoe UI", FontWeight.BOLD, 11));

        page.getChildren().addAll(title, dateText, grid, totalText);
        return page;
    }

    // ---------- file I/O ----------

    private void saveToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (Department d : departments.values()) {
                for (Employee e : d.getEmployees()) {
                    pw.println(d.getName() + "," + e.toFileString());
                }
            }
        } catch (IOException ex) {
            showAlert(Alert.AlertType.ERROR, "Error saving file: " + ex.getMessage());
        }
    }

    private void loadFromFileQuietly() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;
        doLoad(file);
    }

    private void loadFromFileButton() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            showAlert(Alert.AlertType.ERROR, "No saved file found (" + FILE_NAME + ").");
            return;
        }
        doLoad(file);
        refreshDeptCombo();
        refreshTable();
        setStatus("Records loaded from " + FILE_NAME + ".");
    }

    private void doLoad(File file) {
        departments.clear();
        initializeDefaultDepartments();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                String deptName = parts[0];
                String type = parts[1];
                String firstName = parts[2];
                String lastName = parts[3];
                String email = parts[4];
                LocalDate dob = "null".equals(parts[5]) ? null : LocalDate.parse(parts[5]);
                String jobTitle = parts[6];
                EmploymentType empType = EmploymentType.valueOf(parts[7]);
                double hourlyRate = Double.parseDouble(parts[8]);
                double hoursWorked = Double.parseDouble(parts[9]);

                Employee emp;
                switch (type) {
                    case "AcademicStaff":
                        emp = new AcademicStaff(firstName, lastName, email, dob, jobTitle, empType, hourlyRate, hoursWorked, Double.parseDouble(parts[10]));
                        break;
                    case "StudentServicesStaff":
                        emp = new StudentServicesStaff(firstName, lastName, email, dob, jobTitle, empType, hourlyRate, hoursWorked, Double.parseDouble(parts[10]));
                        break;
                    case "AdminStaff":
                        emp = new AdminStaff(firstName, lastName, email, dob, jobTitle, empType, hourlyRate, hoursWorked, Double.parseDouble(parts[10]));
                        break;
                    case "HealthCareStaff":
                        emp = new HealthCareStaff(firstName, lastName, email, dob, jobTitle, empType, hourlyRate, hoursWorked, Double.parseDouble(parts[10]));
                        break;
                    default:
                        continue;
                }
                final String finalType = type;
                Department dept = departments.computeIfAbsent(deptName, n -> new Department(n, categoryFromType(finalType)));
                dept.addEmployee(emp);
                rememberRole(dept.getCategory(), jobTitle);
            }
        } catch (IOException ex) {
            showAlert(Alert.AlertType.ERROR, "Error loading file: " + ex.getMessage());
        }
    }

    // ---------- small helpers ----------

    private void setStatus(String msg) {
        statusLabel.setText(msg);
    }

    private void showAlert(Alert.AlertType type, String message) {
        showAlert(type, message, type == Alert.AlertType.ERROR ? "Error" : "Info");
    }

    private void showAlert(Alert.AlertType type, String message, String title) {
        Alert alert = new Alert(type, message, ButtonType.OK);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
