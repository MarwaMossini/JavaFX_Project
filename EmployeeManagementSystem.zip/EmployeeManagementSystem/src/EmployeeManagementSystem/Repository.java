package EmployeeManagementSystem;

import java.util.ArrayList;
import java.util.List;

/**
 * A generic, reusable storage container.
 * Department uses Repository<Employee>, but this class could just as
 * easily store any type -- that is the point of generics: one class,
 * type-safe for whatever T you plug in.
 */
public class Repository<T> {

    private List<T> items = new ArrayList<>();

    public void add(T item) {
        items.add(item);
    }

    public boolean remove(T item) {
        return items.remove(item);
    }

    public List<T> getAll() {
        return items;
    }

    public int size() {
        return items.size();
    }
}
