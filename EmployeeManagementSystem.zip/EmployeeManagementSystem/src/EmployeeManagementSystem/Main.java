package EmployeeManagementSystem;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * Entry point of the console version. Presents a menu that lets the
 * user manage departments and employees, run payroll calculations,
 * and save/load all records to a plain text file (employees.txt).
 *
 * Pay is hourly: hourlyRate x hoursWorked, plus a category-specific
 * bonus (see Roles.java). Full-time employees are suggested a default
 * of 160 hours/month (40hrs/week x 4 weeks); part-time hours are
 * entered manually since they vary.
 */
public class Main {

    private static Map<String, Department> departments = new HashMap<>();
    private static Scanner sc = new Scanner(System.in);
    private static final String FILE_NAME = "employees.txt";

    public static void main(String[] args) {
        initializeDefaultDepartments();

        int choice;
        do {
            printMenu();
            choice = readInt("Enter choice: ");
            switch (choice) {
                case 1: addDepartment(); break;
                case 2: addEmployee(); break;
                case 3: viewAllDepartments(); break;
                case 4: viewDepartmentEmployees(); break;
                case 5: updateEmployee(); break;
                case 6: calculatePayroll(); break;
                case 7: generatePayslip(); break;
                case 8: saveToFile(); break;
                case 9: loadFromFile(); break;
                case 0: System.out.println("Exiting... Goodbye!"); break;
                default: System.out.println("Invalid choice, try again.");
            }
        } while (choice != 0);
        sc.close();
    }

    private static void printMenu() {
        System.out.println("\n===== University Employee Management System =====");
        System.out.println("1. Add Department");
        System.out.println("2. Add Employee");
        System.out.println("3. View All Departments & Employees");
        System.out.println("4. View Employees in a Department");
        System.out.println("5. Update Employee");
        System.out.println("6. Calculate Payroll");
        System.out.println("7. Generate Payslip");
        System.out.println("8. Save Records to File");
        System.out.println("9. Load Records from File");
        System.out.println("0. Exit");
    }

    // ---------- default data ----------

    private static void initializeDefaultDepartments() {
        addDefaultDept("Undergraduate", Category.ACADEMIC);
        addDefaultDept("Graduate", Category.ACADEMIC);
        addDefaultDept("Pathway", Category.ACADEMIC);
        addDefaultDept("School", Category.ACADEMIC);
        addDefaultDept("Fellows", Category.ACADEMIC);

        addDefaultDept("Registration", Category.STUDENT_SERVICES);
        addDefaultDept("Residential Life", Category.STUDENT_SERVICES);
        addDefaultDept("Library", Category.STUDENT_SERVICES);
        addDefaultDept("Visa Office", Category.STUDENT_SERVICES);
        addDefaultDept("Work-Study", Category.STUDENT_SERVICES);

        addDefaultDept("Finance", Category.ADMINISTRATION);
        addDefaultDept("IT", Category.ADMINISTRATION);
        addDefaultDept("Housekeeping", Category.ADMINISTRATION);
        addDefaultDept("Maintenance", Category.ADMINISTRATION);
        addDefaultDept("Security", Category.ADMINISTRATION);

        addDefaultDept("Health Center", Category.HEALTH_CARE);
        addDefaultDept("Mental Health", Category.HEALTH_CARE);
    }

    private static void addDefaultDept(String name, Category category) {
        departments.put(name, new Department(name, category));
    }

    private static Category categoryFromType(String type) {
        switch (type) {
            case "AcademicStaff": return Category.ACADEMIC;
            case "StudentServicesStaff": return Category.STUDENT_SERVICES;
            case "AdminStaff": return Category.ADMINISTRATION;
            case "HealthCareStaff": return Category.HEALTH_CARE;
            default: return Category.ADMINISTRATION;
        }
    }

    // ---------- input helpers ----------

    private static int readInt(String prompt) {
        System.out.print(prompt);
        while (!sc.hasNextInt()) {
            System.out.print("Please enter a valid whole number: ");
            sc.next();
        }
        int val = sc.nextInt();
        sc.nextLine();
        return val;
    }

    private static double readDouble(String prompt) {
        System.out.print(prompt);
        while (!sc.hasNextDouble()) {
            System.out.print("Please enter a valid number: ");
            sc.next();
        }
        double val = sc.nextDouble();
        sc.nextLine();
        return val;
    }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        return sc.nextLine();
    }

    private static LocalDate readDate(String prompt) {
        while (true) {
            String input = readLine(prompt);
            try {
                return LocalDate.parse(input.trim());
            } catch (DateTimeParseException ex) {
                System.out.println("Please enter a date as YYYY-MM-DD (e.g. 1990-05-21).");
            }
        }
    }

    // ---------- menu actions ----------

    private static void addDepartment() {
        String name = readLine("Enter new department name: ");
        if (departments.containsKey(name)) {
            System.out.println("A department with that name already exists.");
            return;
        }
        System.out.println("Select category: 1) Academic  2) Student Services  3) Administration  4) Health Care");
        int c = readInt("Choice: ");
        Category cat;
        switch (c) {
            case 1: cat = Category.ACADEMIC; break;
            case 2: cat = Category.STUDENT_SERVICES; break;
            case 3: cat = Category.ADMINISTRATION; break;
            case 4: cat = Category.HEALTH_CARE; break;
            default: System.out.println("Invalid category."); return;
        }
        departments.put(name, new Department(name, cat));
        System.out.println("Department '" + name + "' added under " + cat + ".");
    }

    private static Department selectDepartment() {
        if (departments.isEmpty()) {
            System.out.println("No departments yet. Add one first (option 1).");
            return null;
        }
        System.out.println("Available departments: " + new TreeSet<>(departments.keySet()));
        String name = readLine("Enter department name: ");
        Department d = departments.get(name);
        if (d == null) {
            System.out.println("Department not found.");
        }
        return d;
    }

    private static void addEmployee() {
        Department dept = selectDepartment();
        if (dept == null) return;

        String firstName = readLine("First name: ");
        String lastName = readLine("Last name: ");
        String email = readLine("Email: ");
        LocalDate dob = readDate("Date of birth (YYYY-MM-DD): ");
        String jobTitle = readLine("Role (e.g. Doctor, Librarian): ");

        System.out.println("Employment type: 1) Full-time  2) Part-time");
        int typeChoice = readInt("Choice: ");
        EmploymentType type = (typeChoice == 2) ? EmploymentType.PART_TIME : EmploymentType.FULL_TIME;

        double hourlyRate = readDouble("Hourly rate ($): ");
        double hoursWorked;
        if (type == EmploymentType.FULL_TIME) {
            hoursWorked = readDouble("Hours worked this month (suggested 160 for full-time): ");
        } else {
            hoursWorked = readDouble("Hours worked this period (varies for part-time): ");
        }

        try {
            Employee emp;
            switch (dept.getCategory()) {
                case ACADEMIC:
                    double researchPct = readDouble("Research/teaching allowance %: ");
                    emp = new AcademicStaff(firstName, lastName, email, dob, jobTitle, type, hourlyRate, hoursWorked, researchPct);
                    break;
                case STUDENT_SERVICES:
                    double shiftAllowance = readDouble("Shift allowance ($): ");
                    emp = new StudentServicesStaff(firstName, lastName, email, dob, jobTitle, type, hourlyRate, hoursWorked, shiftAllowance);
                    break;
                case ADMINISTRATION:
                    double overtime = readDouble("Overtime hours (paid at 1.5x): ");
                    emp = new AdminStaff(firstName, lastName, email, dob, jobTitle, type, hourlyRate, hoursWorked, overtime);
                    break;
                case HEALTH_CARE:
                    double onCallBonus = readDouble("On-call bonus ($): ");
                    emp = new HealthCareStaff(firstName, lastName, email, dob, jobTitle, type, hourlyRate, hoursWorked, onCallBonus);
                    break;
                default:
                    System.out.println("Unknown category.");
                    return;
            }
            dept.addEmployee(emp);
            System.out.println("Employee added with ID: " + emp.getId());
        } catch (IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void viewAllDepartments() {
        if (departments.isEmpty()) {
            System.out.println("No departments to show.");
            return;
        }
        for (Category cat : Category.values()) {
            for (Department d : departments.values()) {
                if (d.getCategory() == cat) {
                    d.listEmployees();
                }
            }
        }
    }

    private static void viewDepartmentEmployees() {
        Department dept = selectDepartment();
        if (dept != null) dept.listEmployees();
    }

    private static void updateEmployee() {
        Department dept = selectDepartment();
        if (dept == null) return;
        int id = readInt("Enter employee ID to update: ");
        try {
            Employee emp = dept.findEmployeeById(id);
            System.out.println("Current details: " + emp);
            double newRate = readDouble("New hourly rate ($): ");
            double newHours = readDouble("New hours worked: ");
            emp.setHourlyRate(newRate);
            emp.setHoursWorked(newHours);
            System.out.println("Updated successfully.");
        } catch (EmployeeNotFoundException | IllegalArgumentException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void calculatePayroll() {
        System.out.println("1) Department Payroll  2) Company-wide Payroll");
        int c = readInt("Choice: ");
        if (c == 1) {
            Department dept = selectDepartment();
            if (dept != null) {
                System.out.printf("Total payroll for %s: $%,.2f%n", dept.getName(), dept.totalSalaryExpense());
            }
        } else if (c == 2) {
            System.out.printf("Total university payroll: $%,.2f%n", Payroll.calculateCompanyPayroll(departments));
        } else {
            System.out.println("Invalid choice.");
        }
    }

    private static void generatePayslip() {
        Department dept = selectDepartment();
        if (dept == null) return;
        int id = readInt("Enter employee ID: ");
        try {
            Employee emp = dept.findEmployeeById(id);
            Payroll.printPayslip(emp);
        } catch (EmployeeNotFoundException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    // ---------- file I/O ----------

    private static void saveToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (Department d : departments.values()) {
                for (Employee e : d.getEmployees()) {
                    pw.println(d.getName() + "," + e.toFileString());
                }
            }
            System.out.println("Records saved to " + FILE_NAME);
        } catch (IOException ex) {
            System.out.println("Error saving file: " + ex.getMessage());
        }
    }

    private static void loadFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            System.out.println("No saved file found (" + FILE_NAME + ").");
            return;
        }
        departments.clear();
        initializeDefaultDepartments();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                String deptName = parts[0];
                String type = parts[1];
                String firstName = parts[2];
                String lastName = parts[3];
                String email = parts[4];
                LocalDate dob = "null".equals(parts[5]) ? null : LocalDate.parse(parts[5]);
                String jobTitle = parts[6];
                EmploymentType empType = EmploymentType.valueOf(parts[7]);
                double hourlyRate = Double.parseDouble(parts[8]);
                double hoursWorked = Double.parseDouble(parts[9]);

                Employee emp;
                switch (type) {
                    case "AcademicStaff":
                        emp = new AcademicStaff(firstName, lastName, email, dob, jobTitle, empType, hourlyRate, hoursWorked, Double.parseDouble(parts[10]));
                        break;
                    case "StudentServicesStaff":
                        emp = new StudentServicesStaff(firstName, lastName, email, dob, jobTitle, empType, hourlyRate, hoursWorked, Double.parseDouble(parts[10]));
                        break;
                    case "AdminStaff":
                        emp = new AdminStaff(firstName, lastName, email, dob, jobTitle, empType, hourlyRate, hoursWorked, Double.parseDouble(parts[10]));
                        break;
                    case "HealthCareStaff":
                        emp = new HealthCareStaff(firstName, lastName, email, dob, jobTitle, empType, hourlyRate, hoursWorked, Double.parseDouble(parts[10]));
                        break;
                    default:
                        continue;
                }
                final String finalType = type;
                Department dept = departments.computeIfAbsent(deptName, n -> new Department(n, categoryFromType(finalType)));
                dept.addEmployee(emp);
            }
            System.out.println("Records loaded from " + FILE_NAME);
        } catch (IOException ex) {
            System.out.println("Error loading file: " + ex.getMessage());
        }
    }
}
