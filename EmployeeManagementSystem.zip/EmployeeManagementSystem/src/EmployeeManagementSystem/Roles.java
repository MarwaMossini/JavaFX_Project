package EmployeeManagementSystem;

/**
 * This file groups the 4 concrete Employee subclasses -- one per
 * university category -- so all "role" logic lives in a single place.
 * Each subclass builds its pay on top of Employee.baseRegularPay()
 * (hourlyRate x hoursWorked), adding its own category-specific bonus.
 */

/**
 * Staff belonging to an academic department (Undergraduate, Graduate,
 * Pathway, School, Fellows). Earns base pay plus a research/teaching
 * allowance expressed as a percentage of base pay.
 */
class AcademicStaff extends Employee {

    private double researchAllowancePercent;

    public AcademicStaff(String firstName, String lastName, String email, java.time.LocalDate dateOfBirth, String jobTitle,
                          EmploymentType employmentType, double hourlyRate, double hoursWorked,
                          double researchAllowancePercent) {
        super(firstName, lastName, email, dateOfBirth, jobTitle, employmentType, hourlyRate, hoursWorked);
        this.researchAllowancePercent = researchAllowancePercent;
    }

    public double getResearchAllowancePercent() {
        return researchAllowancePercent;
    }

    public void setResearchAllowancePercent(double researchAllowancePercent) {
        this.researchAllowancePercent = researchAllowancePercent;
    }

    @Override
    public double calculateSalary() {
        double base = baseRegularPay();
        return base + (base * researchAllowancePercent / 100.0);
    }

    @Override
    public Category getCategory() {
        return Category.ACADEMIC;
    }

    @Override
    public String toFileString() {
        return super.toFileString() + "," + researchAllowancePercent;
    }
}

/**
 * Staff belonging to a student services department (Registration,
 * Residential Life, Library, Visa Office, Work-Study). Earns base
 * pay plus a fixed shift allowance (many of these roles run
 * evening/weekend shifts).
 */
class StudentServicesStaff extends Employee {

    private double shiftAllowance;

    public StudentServicesStaff(String firstName, String lastName, String email, java.time.LocalDate dateOfBirth, String jobTitle,
                                 EmploymentType employmentType, double hourlyRate, double hoursWorked,
                                 double shiftAllowance) {
        super(firstName, lastName, email, dateOfBirth, jobTitle, employmentType, hourlyRate, hoursWorked);
        this.shiftAllowance = shiftAllowance;
    }

    public double getShiftAllowance() {
        return shiftAllowance;
    }

    public void setShiftAllowance(double shiftAllowance) {
        this.shiftAllowance = shiftAllowance;
    }

    @Override
    public double calculateSalary() {
        return baseRegularPay() + shiftAllowance;
    }

    @Override
    public Category getCategory() {
        return Category.STUDENT_SERVICES;
    }

    @Override
    public String toFileString() {
        return super.toFileString() + "," + shiftAllowance;
    }
}

/**
 * Staff belonging to an administration department (Finance, IT,
 * Housekeeping, Maintenance, Security). Earns base pay plus overtime
 * hours, paid at time-and-a-half (1.5x hourly rate) -- the standard
 * overtime convention.
 */
class AdminStaff extends Employee {

    private static final double OVERTIME_MULTIPLIER = 1.5;

    private double overtimeHours;

    public AdminStaff(String firstName, String lastName, String email, java.time.LocalDate dateOfBirth, String jobTitle,
                       EmploymentType employmentType, double hourlyRate, double hoursWorked,
                       double overtimeHours) {
        super(firstName, lastName, email, dateOfBirth, jobTitle, employmentType, hourlyRate, hoursWorked);
        this.overtimeHours = overtimeHours;
    }

    public double getOvertimeHours() {
        return overtimeHours;
    }

    public void setOvertimeHours(double overtimeHours) {
        this.overtimeHours = overtimeHours;
    }

    @Override
    public double calculateSalary() {
        double overtimePay = overtimeHours * hourlyRate * OVERTIME_MULTIPLIER;
        return baseRegularPay() + overtimePay;
    }

    @Override
    public Category getCategory() {
        return Category.ADMINISTRATION;
    }

    @Override
    public String toFileString() {
        return super.toFileString() + "," + overtimeHours;
    }
}

/**
 * Staff belonging to a health care department (Health Center,
 * Mental Health). Earns base pay plus a fixed on-call/clinical
 * bonus.
 */
class HealthCareStaff extends Employee {

    private double onCallBonus;

    public HealthCareStaff(String firstName, String lastName, String email, java.time.LocalDate dateOfBirth, String jobTitle,
                            EmploymentType employmentType, double hourlyRate, double hoursWorked,
                            double onCallBonus) {
        super(firstName, lastName, email, dateOfBirth, jobTitle, employmentType, hourlyRate, hoursWorked);
        this.onCallBonus = onCallBonus;
    }

    public double getOnCallBonus() {
        return onCallBonus;
    }

    public void setOnCallBonus(double onCallBonus) {
        this.onCallBonus = onCallBonus;
    }

    @Override
    public double calculateSalary() {
        return baseRegularPay() + onCallBonus;
    }

    @Override
    public Category getCategory() {
        return Category.HEALTH_CARE;
    }

    @Override
    public String toFileString() {
        return super.toFileString() + "," + onCallBonus;
    }
}
