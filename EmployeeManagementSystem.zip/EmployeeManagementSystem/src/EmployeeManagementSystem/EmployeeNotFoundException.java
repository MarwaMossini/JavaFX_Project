package EmployeeManagementSystem;

/**
 * Thrown when an employee ID cannot be found within a department.
 * A checked exception, so callers are forced to handle the failure case.
 */
public class EmployeeNotFoundException extends Exception {

    public EmployeeNotFoundException(String message) {
        super(message);
    }
}
