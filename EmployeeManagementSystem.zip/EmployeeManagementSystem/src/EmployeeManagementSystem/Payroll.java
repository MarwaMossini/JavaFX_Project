package EmployeeManagementSystem;

import java.util.Map;

/**
 * Payroll performs salary calculations that span across departments,
 * separate from the data-holding responsibilities of Department itself.
 * It never recomputes salary math on its own -- it always delegates to
 * Employee.calculateSalary(), so there is exactly one place that owns
 * the pay rules.
 */
public class Payroll {

    public static double calculateCompanyPayroll(Map<String, Department> departments) {
        double total = 0;
        for (Department d : departments.values()) {
            total += d.totalSalaryExpense();
        }
        return total;
    }

    public static void printPayslip(Employee e) {
        System.out.println("========== PAYSLIP ==========");
        System.out.println("Employee   : " + e.getFullName() + " (ID: " + e.getId() + ")");
        System.out.println("Email      : " + e.getEmail());
        System.out.println("Date of Birth : " + e.getDateOfBirth() + " (age " + e.getAge() + ")");
        System.out.println("Title      : " + e.getJobTitle());
        System.out.println("Type       : " + e.getEmploymentType());
        System.out.printf("Hourly Rate: $%,.2f%n", e.getHourlyRate());
        System.out.printf("Hours      : %.1f%n", e.getHoursWorked());
        System.out.println("Category   : " + e.getCategory());
        System.out.printf("Net Pay    : $%,.2f%n", e.calculateSalary());
        System.out.println("==============================");
    }
}
