# University Employee Management System (JavaFX)

A JavaFX desktop application for the Asian University for Women's HR/
registrar office. Built around 4 role subclasses (inheritance +
polymorphism), hourly-based pay calculation, and a full CRUD interface
with a Home page, statistics, and printing.

## How to run in Eclipse

1. Import this folder via **File > Import... > General > Existing
   Projects into Workspace** (it already has `.project`/`.classpath`).
2. Add the JavaFX SDK to Build Path: right-click project > **Build
   Path > Configure Build Path > Libraries > Add External JARs...**
   and select every `.jar` in your JavaFX SDK's `lib` folder.
3. Right-click `MainApp.java` > **Run As > Run Configurations...** >
   **Arguments** tab > VM arguments:
   ```
   --module-path "C:\path\to\javafx-sdk\lib" --add-modules javafx.controls
   ```
4. Run. `Main.java` (console version) can be run directly with no
   extra setup, if you ever want the plain text-menu version instead.

## What's in this version

- **Home page** with the AUW logo, then "Enter Employee Management
  System" to reach the full app. A "← Home" button in the header
  goes back.
- **Add / View / Search / Update / Delete Employee**, **View
  Departments**, **Payroll**, **Statistics** (bar chart), **Print**,
  **Save/Load Records**, **Exit** — all reachable from the management
  screen's sidebar and toolbar.
- **Hourly pay model**: every employee is paid `hourlyRate x
  hoursWorked`, plus a role-specific bonus on top:
  - Academic: + research/teaching allowance (% of base pay)
  - Student Services: + shift allowance ($)
  - Administration: + overtime hours, paid at **1.5x** hourly rate
  - Health Care: + on-call bonus ($)
  - **Full-time** employees default to 160 hours (40hrs/week x 4
    weeks), editable. **Part-time** employees start blank since hours
    vary per pay period.
- **Add Employee form** now collects: First name, Last name, Email,
  Role, Employment type, Hourly rate, Hours worked, plus the
  role-specific field above.
- **Statistics**: a bar chart of employee count by division, colored
  to match each division's color (see Division Key).
- **Print**: builds a formatted employee report (ID, name, role,
  department, type, salary, grouped by department) and sends it to
  Java's real print dialog.
- **Auto-save**: every add/update/delete writes to `employees.txt`
  immediately; the file loads automatically on startup.
- **AUW branding**: the actual university logo (`auw_logo.png`)
  appears on the Home page and in the header — must stay in
  `src/EmployeeManagementSystem/` alongside the `.java` files, since
  it's loaded as a classpath resource.

## File-by-file guide

| File | Contains |
|---|---|
| `MainApp.java` | JavaFX GUI: Home page, management screen, all dialogs, chart, print |
| `Employee.java` | Abstract `Employee` base class + `EmploymentType` enum |
| `Roles.java` | `AcademicStaff`, `StudentServicesStaff`, `AdminStaff`, `HealthCareStaff` |
| `Department.java` | `Department` class + `Category` enum |
| `Payroll.java` | Company-wide payroll totals, console payslip formatting |
| `Repository.java` | Generic `Repository<T>` collection wrapper |
| `EmployeeNotFoundException.java` | Custom checked exception |
| `Main.java` | Console (text-menu) version, kept in sync with the same model |
| `styles.css` | Visual identity: Ink Navy / Brass / Parchment theme |
| `auw_logo.png` | University logo, used on Home page and header |

## Data structures used

- `HashMap<String, Department>` — departments keyed by name (fast lookup)
- `ArrayList<Employee>` (inside `Repository<T>`) — employees per department
- `enum Category`, `enum EmploymentType` — fixed, type-safe constants

## Sample file format (`employees.txt`)

```
Health Center,HealthCareStaff,Marwa,Rahman,marwa@auw.edu.bd,Chief Doctor,FULL_TIME,25.0,160.0,500.0
```

Format: `department,type,firstName,lastName,email,role,employmentType,hourlyRate,hoursWorked,extraField`

## What's new in this version

- **Sample data on first run**: 15 realistic employees across all 4
  divisions are seeded automatically the first time you run the app
  (only if `employees.txt` doesn't already exist yet) — so it never
  opens looking empty. Once you have your own data saved, this seeding
  never happens again.
- **Role field is now an editable dropdown** (`roleCombo`): pick from
  a starter list of common job titles for that department's category
  (e.g. Health Care gets Doctor, Nurse, Psychologist...), or just type
  a custom one. Custom roles automatically become suggestions for next
  time too, since the list is derived from whoever's actually in the
  system — no extra data file needed.
- **Date of Birth** with a real calendar `DatePicker`, shown in the
  table (as computed **Age**), the Add/Update forms, and the Payslip.

## A DatePicker quirk I found and fixed

JavaFX's `DatePicker` doesn't always commit typed text to its value
when you Tab away — it depends on the JVM's default locale matching
the date format you typed. I ran into this myself (a typed date
silently produced a null `dateOfBirth`, showing up as "Age: -1") and
fixed it two ways: an explicit ISO `yyyy-MM-dd` converter on the
picker, plus a fallback that reads the editor's raw text directly if
the picker's value comes back empty. `addEmployee()` also now refuses
to save without a valid date, so this can't silently happen again.
